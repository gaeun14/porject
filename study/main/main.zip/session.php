<?php
// 세션 상태를 확인합니다
echo "Current session status: " . session_status();
?>
